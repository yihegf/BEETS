# bt-in-githab-server
使用方法
白嫖githab服务器
前提：先创建这个仓库的代码空间
1先运行【sudo su】（获取root权限）
2看官网bt.cn Linux安装命令全能脚本，让后运行（安装宝塔面板）
3然后运行【sh btvip.sh】（升级到开心版，可不运行）
4最后运行【rm -f /www/server/panel/data/admin_path.pl】（删除面板安全入口）
安装完成，访问宝塔面板
备注：可以多次白嫖呦
